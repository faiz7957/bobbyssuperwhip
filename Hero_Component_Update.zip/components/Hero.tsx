"use client";

import Image from "next/image";

export default function Hero() {
  return (
    <section className="relative isolate min-h-[100svh] overflow-hidden">
      <Image
        src="/images/van.png"
        alt="Bobby's Super Whip Ice Cream Van"
        fill
        priority
        className="object-cover object-[72%_center] md:object-center scale-105"
      />

      <div className="absolute inset-0 bg-gradient-to-r from-sky-950/75 via-sky-900/35 to-transparent" />

      <div className="relative z-10 mx-auto flex min-h-[100svh] max-w-7xl items-center px-6 py-28">
        <div className="max-w-xl rounded-3xl border border-white/20 bg-slate-900/25 p-10 backdrop-blur-xl shadow-2xl">

          <span className="inline-flex rounded-full bg-sky-500 px-4 py-2 text-sm font-semibold text-white">
            🍦 Serving the Midlands since 2016
          </span>

          <h1 className="mt-6 text-6xl font-black leading-none text-white md:text-8xl">
            Bobby's
            <span className="block text-yellow-300">Super Whip</span>
          </h1>

          <p className="mt-6 text-2xl font-bold text-white">
            It's Not A Dream,<br />
            It's Bobby's Ice Cream!
          </p>

          <p className="mt-6 text-lg leading-8 text-white/90">
            Premium whipped ice cream, delicious slush, sundaes and event catering across Walsall and the Midlands.
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a href="#events" className="rounded-xl bg-yellow-400 px-8 py-4 text-center font-bold text-slate-900 hover:bg-yellow-300 transition">
              Book an Event
            </a>

            <a href="#treats" className="rounded-xl border-2 border-white px-8 py-4 text-center font-semibold text-white hover:bg-white hover:text-slate-900 transition">
              View Our Treats
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
